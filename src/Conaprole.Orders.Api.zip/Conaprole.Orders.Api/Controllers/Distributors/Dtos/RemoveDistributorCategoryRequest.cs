namespace Conaprole.Orders.Api.Controllers.Distributors.Dtos;

public record RemoveDistributorCategoryRequest(
    string Category
);