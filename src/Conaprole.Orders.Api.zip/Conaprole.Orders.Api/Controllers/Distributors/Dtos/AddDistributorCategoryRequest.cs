namespace Conaprole.Orders.Api.Controllers.Distributors.Dtos;

public record AddDistributorCategoryRequest(
    string Category
);