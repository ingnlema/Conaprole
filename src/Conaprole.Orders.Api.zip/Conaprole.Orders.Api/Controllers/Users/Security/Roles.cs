namespace Conaprole.Orders.Api.Controllers;

public static class Roles
{
    public const string Registered = "Registered";
}
