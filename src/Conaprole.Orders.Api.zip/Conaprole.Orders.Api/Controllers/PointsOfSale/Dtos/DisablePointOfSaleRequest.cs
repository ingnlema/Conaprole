namespace Conaprole.Orders.Api.Controllers.PointsOfSale.Dtos;

public record DisablePointOfSaleRequest(string PhoneNumber);